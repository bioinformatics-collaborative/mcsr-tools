rm -R r2294/
rm temp_yaml.yml
rm -R qwait_test/
rm checker_log.log
