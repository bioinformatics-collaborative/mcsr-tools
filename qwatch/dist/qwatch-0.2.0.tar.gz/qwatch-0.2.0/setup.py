# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['qwatch', 'qwatch.utils']

package_data = \
{'': ['*']}

install_requires = \
['click (>=6.7.0.0,<7.0.0.0)',
 'pandas (>=0.22.0.0,<0.23.0.0)',
 'pyaml (>=17.12.0.0,<18.0.0.0)']

entry_points = \
{'console_scripts': ['qwatch = qwatch.cli:qwatch']}

setup_kwargs = {
    'name': 'qwatch',
    'version': '0.2.0',
    'description': 'The qwatch package was developed with pbs_version = 14.1.0 using the Mississippi Center for\nComputational Research (MCSR).  Its primary function is to parse qstat -f data over time.  The data and plots\nproduced allow the user to make smarter decision regarding resource allocation for downstream batch jobs.',
    'long_description': '# qwatch\nqwatch is a command line utility for monitoring PBS jobs on the MCSR (and perhaps similar systems)\n\n## Outline\n* Look up qstat commands for inspiration\n* Command line development:\n    * _--user_ option displays info about all of the jobs from a specific user/list of users\n    * _--job_ option displays info about a specific job/list of jobs\n    * _--watch_ argument watches the jobs of interest over time\n    * _--output_ option is a filename for the output\n    * _--data_file_ option is a file name for the data monitoring\n    * _--plot_data_ argument plots the data in the data_file.  (requires the --data_file_ option)\n    * _--notify_ option is used to notify the user by email or by slack.\n* Future development:\n    * --database option for naming a new or old database for storing job data\n\n',
    'author': 'Rob Gilmore',
    'author_email': 'rgilmore@umc.edu',
    'url': 'https://github.com/bioinformatics-collaborative/mcsr-tools/tree/qwatch_branch/qwatch',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>= 3.6.0.0, < 4.0.0.0',
}


setup(**setup_kwargs)
